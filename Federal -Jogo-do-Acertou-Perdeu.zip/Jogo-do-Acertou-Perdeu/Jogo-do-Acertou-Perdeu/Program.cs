﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jogo_do_Acertou_Perdeu
{
    internal class Program
    {
        static void Main(string[] args)
        { 


            Random random = new Random();

            Console.WriteLine("Bem-vindo ao Jogo do Acertou mas, perdeu.");
            Console.WriteLine("Onde você compete contra outro jogador para ver quem adivinha o jogo mais rapido, assim perdendo.");
    
            int numJogadores;
            while (true) 
            {
                Console.Write("Quantos jogadores irão jogar? ");
                string inputJogadores = Console.ReadLine();
                if (int.TryParse(inputJogadores, out numJogadores) && numJogadores > 0)
                {
                    break; 
                }
                else
                {
                    Console.WriteLine("Por favor, digite um número válido de jogadores (maior que zero).");
                }
            }

            int tentativas = 100; 
            bool[] jogadorAcertou = new bool[numJogadores]; 
            int limiteInferior = 1;
            int limiteSuperior = 100;


            int numeroOculto = random.Next(limiteInferior, limiteSuperior + 1); 

            Console.WriteLine($"\nO jogo vai começar! O número oculto está entre {limiteInferior} e {limiteSuperior}.");

            for (int tentativaAtual = 0; tentativaAtual < tentativas; tentativaAtual++)
            {
                Console.WriteLine($"\n--- Rodada {tentativaAtual + 1} de {tentativas} ---");

              
                for (int i = 0; i < numJogadores; i++)
                {
                    if (jogadorAcertou[i])
                    {
                        Console.WriteLine($"Jogador {i + 1} já acertou e está fora do jogo!");
                        continue; 
                    }

                    Console.WriteLine($"\n--- Jogador {i + 1} ---");
                    Console.WriteLine($"Limite Inferior do Jogo: {limiteInferior}");
                    Console.WriteLine($"Limite Superior do Jogo: {limiteSuperior}");

                    int palpite;
                    while (true) 
                    {
                        Console.Write($"Jogador {i + 1}, faça seu palpite (tentativa {tentativaAtual + 1} de {tentativas}): ");
                        string inputPalpite = Console.ReadLine();
                        if (int.TryParse(inputPalpite, out palpite) && palpite >= limiteInferior && palpite <= limiteSuperior)
                        {
                            break; 
                        }
                        else
                        {
                            Console.WriteLine($"Palpite inválido! Digite um número entre {limiteInferior} e {limiteSuperior}.");
                        }
                    }

                   
                    if (palpite == numeroOculto)
                    {
                        Console.WriteLine($"Parabéns, Jogador {i + 1}! Você acertou o número {numeroOculto}!");
                        jogadorAcertou[i] = true; 
                    }
                    else
                    {
                        Console.WriteLine("Errou!");
                        if (palpite < numeroOculto)
                        {
                            Console.WriteLine("O número oculto é MAIOR.");
                        }
                        else
                        {
                            Console.WriteLine("O número oculto é MENOR.");
                        }
                    }
                }

                if (Array.Exists(jogadorAcertou, x => x))
                {
                    Console.WriteLine("\n--- Fim do Jogo ---");
                    Console.WriteLine("Um ou mais jogadores acertaram o número!");
                    break; 
                }
                else if (tentativaAtual == tentativas - 1) 
                {
                    Console.WriteLine("\n--- Fim do Jogo ---");
                    Console.WriteLine($"Nenhum jogador acertou! O número oculto era {numeroOculto}.");
                    break; 
                }
            }

            if (!Array.Exists(jogadorAcertou, x => x) && tentativaAtual == tentativas)
            {
                Console.WriteLine("\n--- Fim do Jogo ---");
                Console.WriteLine($"Todas as tentativas acabaram. O número oculto era {numeroOculto}.");
            }

            Console.WriteLine("\nPressione qualquer tecla para sair.");
            Console.ReadKey();
        }
    }
}

